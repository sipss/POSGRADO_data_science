installChemometricsWithRData <- function() {
  devtools::install_github("rwehrens/CWR", subdir = "ChemometricsWithRData")

  invisible()
}
